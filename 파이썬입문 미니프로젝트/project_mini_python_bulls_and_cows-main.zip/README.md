## 파이썬 미니프로젝트

### 숫자 야구게임 + psycopg2(postgres)을 살짝 곁드린