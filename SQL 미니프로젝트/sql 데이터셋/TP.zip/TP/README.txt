C 드라이브에 TP 폴더 저장 ->teamproject 쿼리문 실행 -> SQL shell 열기 -> 아래 코드 한 줄 씩 복붙
개수 = bd 1486 / service 63 / 그 외  132321 



\COPY BD FROM 'C:\TP\bdcode.csv' DELIMITER ',' CSV HEADER;
\COPY Service FROM 'C:\TP\Service.csv' DELIMITER ',' CSV HEADER;


\COPY quarter_sales FROM 'C:\TP\quarter_sales.csv' DELIMITER ',' CSV HEADER;
\COPY age_sales FROM 'C:\TP\age_sales.csv' DELIMITER ',' CSV HEADER;
\COPY time_sales FROM 'C:\TP\time_sales.csv' DELIMITER ',' CSV HEADER;
\COPY week_sales FROM 'C:\TP\week_sales.csv' DELIMITER ',' CSV HEADER;
\COPY gender_sales FROM 'C:\TP\gender_sales.csv' DELIMITER ',' CSV HEADER;